-- Monklanians example script (Wololoader Lua API; see MODDING.md).
print("loaded " .. MOD.name .. " v" .. MOD.version)

Game.OnStart(function()
    UI.Message("Monklanians: Wololo!")
end)

-- A counter line that shows how many monks the player has, updated every second.
local monkCounter = UI:CreateCounter("Monks: 0")
Game.OnSecond(function()
    local me = Game.LocalPlayer
    if me then monkCounter:SetText("Monks: " .. #me:Units("Monk")) end
end)

-- Celebrate new monks.
Game.OnUnitCreated(function(unit)
    if unit.ClassName == "Monk" and unit.Owner.IsLocal then UI.Message("A new monk joins the order.") end
end)

-- The Abbey (unit 1400, the first mod building slot) is finished.
Game.OnBuildingDone(function(b)
    if b.Type == 1400 and b.Owner == Game.LocalPlayer then
        UI.Message("The Abbey is finished: train monks and Abbots there.")
    end
end)

-- The Abbey's "Bless" button (unique_building commands, "lua": "Bless" in the civ JSON).
Game.OnCommand("Bless", function(abbey)
    local me = Game.LocalPlayer
    if me.Gold < 50 then
        UI.Message("Not enough gold to bless (50).")
        return
    end
    me:AddGold(-50)
    me:CreateUnit(125, (abbey.X or 0) + 3, (abbey.Y or 0) + 3)
    Sound.Play("TownBell")
end)
