-- Merchant Caravans: every few game minutes the local player receives resources.
-- Everything is set on the Mods screen (Settings) and read from MOD.settings.
-- Each computer only gives its own player resources, so multiplayer stays fair.
local S = MOD.settings or {}   -- nil before Wololoader 0.5.1: the defaults below are used
local seconds = (S.minutes or 3) * 60

local function caravan()
    local me = Game.LocalPlayer
    if not me then return end
    local amount = S.amount or 60
    -- Dark Age x1, Feudal x1.5, Castle x2, Imperial x2.5
    if S.grow ~= false and me.Age then amount = math.floor(amount * (1 + me.Age * 0.5)) end
    me:AddResource(S.resource or "Gold", amount)
    if S.announce ~= false then
        UI.Message("A merchant caravan arrives: +" .. amount .. " " .. (S.resource or "Gold"))
        Sound.Play("Tribute")
    end
end

Game.OnStart(function()
    Time.Every(seconds, caravan)
    print("caravans every " .. seconds .. " s, " .. (S.amount or 60) .. " " .. (S.resource or "Gold"))
end)
